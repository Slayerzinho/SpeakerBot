import { useState } from "react";
import { Button } from "@/react-app/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/react-app/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/react-app/components/ui/card";
import { Badge } from "@/react-app/components/ui/badge";
import { Coins, Dices, Pickaxe, Settings, Heart, Star, Shield, ExternalLink, MessageCircle } from "lucide-react";
interface Command {
  name: string;
  description: string;
}
interface CommandCategory {
  id: string;
  title: string;
  icon: React.ReactNode;
  color: string;
  commands: Command[];
}
const commandCategories: CommandCategory[] = [{
  id: "economia",
  title: "Economia",
  icon: <Coins className="w-5 h-5" />,
  color: "bg-yellow-500/20 text-yellow-500 border-yellow-500/30",
  commands: [{
    name: "banco",
    description: "Verifique seu saldo bancário"
  }, {
    name: "atm",
    description: "Acesse o caixa eletrônico"
  }, {
    name: "daily",
    description: "Colete sua recompensa diária"
  }, {
    name: "pagar",
    description: "Transfira dinheiro para outros usuários"
  }, {
    name: "ranking",
    description: "Veja o ranking de economia"
  }, {
    name: "work",
    description: "Trabalhe para ganhar dinheiro"
  }, {
    name: "tasks",
    description: "Complete tarefas especiais"
  }]
}, {
  id: "apostas",
  title: "Apostas",
  icon: <Dices className="w-5 h-5" />,
  color: "bg-red-500/20 text-red-500 border-red-500/30",
  commands: [{
    name: "bet",
    description: "Faça uma aposta"
  }, {
    name: "copos",
    description: "Jogo dos copos"
  }, {
    name: "mines",
    description: "Campo minado"
  }, {
    name: "race",
    description: "Corrida de animais"
  }, {
    name: "dados",
    description: "Role os dados"
  }]
}, {
  id: "rpg",
  title: "RPG",
  icon: <Pickaxe className="w-5 h-5" />,
  color: "bg-purple-500/20 text-purple-500 border-purple-500/30",
  commands: [{
    name: "minerar",
    description: "Minere recursos valiosos"
  }, {
    name: "mochila",
    description: "Veja seu inventário"
  }, {
    name: "tabelas",
    description: "Consulte tabelas de itens"
  }]
}, {
  id: "utilidades",
  title: "Utilidades",
  icon: <Settings className="w-5 h-5" />,
  color: "bg-blue-500/20 text-blue-500 border-blue-500/30",
  commands: [{
    name: "avatar",
    description: "Veja o avatar de um usuário"
  }, {
    name: "botinfo",
    description: "Informações sobre o bot"
  }, {
    name: "ping",
    description: "Verifique a latência do bot"
  }, {
    name: "invite",
    description: "Link de convite do bot"
  }]
}, {
  id: "social",
  title: "Social",
  icon: <Heart className="w-5 h-5" />,
  color: "bg-pink-500/20 text-pink-500 border-pink-500/30",
  commands: [{
    name: "rep",
    description: "Dê reputação a alguém"
  }, {
    name: "historia",
    description: "Veja a história de alguém"
  }, {
    name: "afk",
    description: "Ative o modo AFK"
  }, {
    name: "perfil",
    description: "Veja seu perfil"
  }, {
    name: "casar",
    description: "Case-se com alguém"
  }, {
    name: "divorciar",
    description: "Termine seu casamento"
  }]
}, {
  id: "premium",
  title: "Premium",
  icon: <Star className="w-5 h-5" />,
  color: "bg-amber-500/20 text-amber-500 border-amber-500/30",
  commands: [{
    name: "emoji edit",
    description: "Edite emojis personalizados"
  }, {
    name: "vip",
    description: "Benefícios VIP"
  }, {
    name: "patrocinar",
    description: "Torne-se um patrocinador"
  }]
}, {
  id: "moderacao",
  title: "Moderação",
  icon: <Shield className="w-5 h-5" />,
  color: "bg-green-500/20 text-green-500 border-green-500/30",
  commands: [{
    name: "setprefix",
    description: "Altere o prefixo do bot"
  }, {
    name: "lock",
    description: "Bloqueie um canal"
  }, {
    name: "unlock",
    description: "Desbloqueie um canal"
  }, {
    name: "clear",
    description: "Limpe mensagens do chat"
  }]
}];
export default function HomePage() {
  const [selectedCategory, setSelectedCategory] = useState<string>("economia");
  const currentCategory = commandCategories.find(cat => cat.id === selectedCategory);
  return <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-blue-500/10 via-purple-500/5 to-transparent" />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZGVmcz48cGF0dGVybiBpZD0iZ3JpZCIgd2lkdGg9IjQwIiBoZWlnaHQ9IjQwIiBwYXR0ZXJuVW5pdHM9InVzZXJTcGFjZU9uVXNlIj48cGF0aCBkPSJNIDQwIDAgTCAwIDAgMCA0MCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSJyZ2JhKDI1NSwgMjU1LCAyNTUsIDAuMDMpIiBzdHJva2Utd2lkdGg9IjEiLz48L3BhdHRlcm4+PC9kZWZzPjxyZWN0IHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiIGZpbGw9InVybCgjZ3JpZCkiLz48L3N2Zz4=')] opacity-40" />
        
        <div className="relative container mx-auto px-4 py-16">
          <div className="flex flex-col items-center text-center space-y-8">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full blur-3xl opacity-20 animate-pulse" />
              <img src="https://019c30f9-45e1-77e2-beb7-3604c0754f02.mochausercontent.com/SpeakerPFPReworkedF.png" alt="Speaker Bot" className="w-32 h-32 rounded-full shadow-2xl border-4 border-white/10 relative" />
            </div>

            <div className="space-y-4">
              <h1 className="text-6xl font-bold text-white">
                Speaker Bot
              </h1>
              <p className="text-xl text-slate-300 max-w-2xl">
                Bot multifuncional para Discord com economia, RPG, apostas e muito mais!
              </p>
            </div>

            <div className="flex flex-wrap gap-4 justify-center">
              <Button size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg shadow-blue-500/25" onClick={() => window.open("https://discord.com/oauth2/authorize?client_id=1214069584626450462&scope=bot%20applications.commands&permissions=2146958847", "_blank")}>
                <ExternalLink className="w-5 h-5 mr-2" />
                Adicionar ao Discord
              </Button>
              <Button size="lg" variant="outline" className="border-slate-700 hover:bg-slate-800 text-white" onClick={() => window.open("https://discord.gg/8FvUpSkfnT", "_blank")}>
                <MessageCircle className="w-5 h-5 mr-2" />
                Servidor de Suporte
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-white mb-4">
            Recursos do Bot
          </h2>
          <p className="text-slate-400 text-lg">
            Explore todas as funcionalidades disponíveis
          </p>
        </div>

        {/* Category Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-12">
          {commandCategories.map(category => <Card key={category.id} className={`bg-slate-900/50 border-slate-800 hover:border-slate-700 transition-all cursor-pointer ${selectedCategory === category.id ? "ring-2 ring-blue-500 ring-offset-2 ring-offset-slate-950" : ""}`} onClick={() => setSelectedCategory(category.id)}>
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg border ${category.color}`}>
                    {category.icon}
                  </div>
                  <CardTitle className="text-white text-lg">
                    {category.title}
                  </CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <Badge variant="secondary" className="bg-slate-800 text-slate-300">
                  {category.commands.length} comandos
                </Badge>
              </CardContent>
            </Card>)}
        </div>

        {/* Category Selector and Commands Display */}
        <div className="space-y-6">
          <div className="flex justify-center">
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger className="w-[300px] bg-slate-900 border-slate-800 text-white">
                <SelectValue placeholder="Selecione uma categoria" />
              </SelectTrigger>
              <SelectContent className="bg-slate-900 border-slate-800">
                {commandCategories.map(category => <SelectItem key={category.id} value={category.id} className="text-white focus:bg-slate-800">
                    <div className="flex items-center gap-2">
                      {category.icon}
                      {category.title}
                    </div>
                  </SelectItem>)}
              </SelectContent>
            </Select>
          </div>

          {currentCategory && <Card className="bg-slate-900/80 border-slate-800 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center gap-3 mb-2">
                  <div className={`p-3 rounded-lg border ${currentCategory.color}`}>
                    {currentCategory.icon}
                  </div>
                  <CardTitle className="text-white text-2xl">
                    {currentCategory.title}
                  </CardTitle>
                </div>
                <CardDescription className="text-slate-400">
                  {currentCategory.commands.length} comandos disponíveis nesta categoria
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {currentCategory.commands.map(command => <div key={command.name} className="p-4 rounded-lg bg-slate-800/50 border border-slate-700 hover:bg-slate-800 transition-colors">
                      <div className="font-mono text-blue-400 font-semibold mb-1">
                        /{command.name}
                      </div>
                      <div className="text-sm text-slate-400">
                        {command.description}
                      </div>
                    </div>)}
                </div>
              </CardContent>
            </Card>}
        </div>
      </div>

      {/* Rules Section */}
      <div className="container mx-auto px-4 py-16">
        <Card className="bg-slate-900/80 border-slate-800 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white text-2xl flex items-center gap-2">
              <Shield className="w-6 h-6" />
              Regras e Diretrizes
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-slate-300">
            <div className="space-y-2">
              <h3 className="font-semibold text-lg text-white">📋 Regras Gerais</h3>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Respeite todos os usuários do servidor</li>
                <li>Não abuse dos comandos do bot</li>
                <li>Não tente explorar bugs ou falhas</li>
                <li>Mantenha um ambiente saudável e divertido</li>
              </ul>
            </div>
            
            <div className="space-y-2">
              <h3 className="font-semibold text-lg text-white">🎯 Economia e Apostas</h3>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Não crie múltiplas contas para ganhar vantagens</li>
                <li>Apostas são apenas para diversão</li>
                <li>O uso de bots ou automação é proibido</li>
                <li>Respeite os limites diários estabelecidos</li>
              </ul>
            </div>

            <div className="space-y-2">
              <h3 className="font-semibold text-lg text-white">⚠️ Consequências</h3>
              <ul className="list-disc list-inside space-y-1 ml-4">
                <li>Violações podem resultar em suspensão temporária</li>
                <li>Violações graves podem resultar em banimento permanente</li>
                <li>Exploits podem resultar em reset de progresso</li>
                <li>Comportamento abusivo será reportado aos moderadores</li>
              </ul>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-800 bg-slate-900/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex items-center gap-3">
              <img src="https://019c30f9-45e1-77e2-beb7-3604c0754f02.mochausercontent.com/SpeakerPFPReworkedF.png" alt="Speaker Bot" className="w-10 h-10 rounded-full" />
              <span className="text-slate-300 font-semibold">Speaker Bot</span>
            </div>
            <div className="text-slate-400 text-sm">© 2026 Speaker Bot. Todos os direitos reservados.</div>
          </div>
        </div>
      </footer>
    </div>;
}